//
//  PageMenu.h
//  PageMenu
//
//  Created by Xorosho on 7/2/15.
//  Copyright (c) 2015 i.kolpachkov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PageMenu.
FOUNDATION_EXPORT double PageMenuVersionNumber;

//! Project version string for PageMenu.
FOUNDATION_EXPORT const unsigned char PageMenuVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PageMenu/PublicHeader.h>


