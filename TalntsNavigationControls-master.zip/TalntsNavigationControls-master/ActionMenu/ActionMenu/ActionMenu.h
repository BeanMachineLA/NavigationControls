//
//  ActionMenu.h
//  ActionMenu
//
//  Created by Xorosho on 7/2/15.
//  Copyright (c) 2015 i.kolpachkov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ActionMenu.
FOUNDATION_EXPORT double ActionMenuVersionNumber;

//! Project version string for ActionMenu.
FOUNDATION_EXPORT const unsigned char ActionMenuVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ActionMenu/PublicHeader.h>


