//
//  ActionMenuItem.swift
//  TalntsNavigationControls
//
//  Created by Xorosho on 7/1/15.
//  Copyright (c) 2015 Xorosho. All rights reserved.
//

import Foundation
import UIKit

public class ActionMenuItem: UIButton
{
    private let kTitleLabelWidth: CGFloat = 200.0
    private let kLabelAndIconGap: CGFloat = 10.0
    private let kTitleLabelHeight: CGFloat = 16.0
    private let kTitleLabelFontSize: CGFloat = 14.0
    
    public typealias ItemTapCallback = (item: ActionMenuItem)->Void
    public var tapCallback: ItemTapCallback?
  
    public var initialPosition: CGPoint = CGPointZero
    public var homePosition: CGPoint = CGPointZero
    public var iconImageView: UIImageView?
    public var itemTitleLabel: UILabel!
    
    
    public func activate()
    {
        self.alpha = 1.0
        self.enabled = true
    }
    
    public func deactivate()
    {
        self.alpha = 0.0
        self.enabled = false
    }
    
    public convenience init(center: CGPoint, iconImageName: String, title: String?, tapCallback: ItemTapCallback? = nil)
    {
        let kMenuItemSize = CGSizeMake(80, 80)
        let iconFrame = CGRectMake(0, 0, kMenuItemSize.width, kMenuItemSize.height)
        self.init(frame: iconFrame)
        self.initialPosition = center
        self.tapCallback = tapCallback
        
        //icon image creation
        let image = UIImage(named: iconImageName)
        iconImageView = UIImageView(image: image)
        let iconImageViewCenter = CGPointMake(kMenuItemSize.width/2.0, kMenuItemSize.height/2.0)
        iconImageView?.center = iconImageViewCenter
        if let iconView = iconImageView { self.addSubview(iconView) }
        
        //title label creation
        let imageWidth = (image?.size.width ?? 0)/2.0
        let labelX = iconImageViewCenter.x - imageWidth - kLabelAndIconGap - kTitleLabelWidth
        let labelY = iconImageViewCenter.y - kTitleLabelHeight/2.0
        let labelFrame = CGRectMake(labelX, labelY, kTitleLabelWidth, kTitleLabelHeight)
        itemTitleLabel = UILabel(frame: labelFrame)
        itemTitleLabel.font = UIFont.systemFontOfSize(kTitleLabelFontSize)
        itemTitleLabel.textColor = UIColor.whiteColor()
        itemTitleLabel.textAlignment = .Right;
        itemTitleLabel.text = title
        itemTitleLabel.alpha = 0.0
        self.addSubview(itemTitleLabel)
    }
    
    public func appearWithAnimation()
    {
        self.activate()
        self.alpha = 0.0
        UIView.animateWithDuration(0.2, delay: 0.0, options:.CurveEaseOut, animations: { () -> Void in
            self.alpha = 1.0
            self.center = self.initialPosition
        }, completion: nil)

        UIView.animateKeyframesWithDuration(0.1, delay: 0.2, options: [], animations: { () -> Void in
            self.itemTitleLabel.alpha = 1.0
        }, completion:nil)
    }
    
    public func disappearWithAnimation()
    {
        self.itemTitleLabel.alpha = 0.0
        UIView.animateWithDuration(0.2, delay: 0.0, options:.CurveEaseIn, animations: { () -> Void in
            self.center = self.homePosition
            self.alpha = 0.0
        }, completion: nil)
    }
    
    public func playItemTappedAnimation(callback: ()->Void)
    {
        UIView.animateWithDuration(0.2, animations: { () -> Void in
            self.enabled = false
            self.alpha = 0.0
            self.iconImageView?.transform = CGAffineTransformMakeScale(1.25, 1.25)
        })
        {
                (finished:Bool)->Void in
                self.iconImageView?.transform = CGAffineTransformMakeScale(1.0, 1.0)
                callback()
                if let itemCallback = self.tapCallback { itemCallback(item: self) }
        }
    }
}

